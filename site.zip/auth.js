var AUTH_CREDENTIALS = {
  email: 'landawork@tuta.io',
  password: 'xXf3ty45ASFdgfh'
};

function checkAuth() {
  if (sessionStorage.getItem('authenticated') !== 'true') {
    window.location.href = 'login.html';
  }
}
